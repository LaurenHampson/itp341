/* EDIT THIS FILE */

package itp341.javareview.superhero;

import java.util.Random;

public class Superhero
{
    private String name; // represents the name of the hero
    private int healthPoints; // represents the hero's health points
    private int attackValue; // represents the strength of the hero's attack

    public static final int MAX_HEALTHPOINTS = 100;
    public static final int MAX_ATTACKVALUE = 20;
    public static int MIN_HEALTHPOINTS = 0;
    public static int MIN_ATTACKVALUE = 5;

    public Superhero(String _name)
    {
        this.name = _name;
        this.healthPoints = MAX_HEALTHPOINTS;

        Random rand = new Random();
        int randVal = rand.nextInt(MAX_ATTACKVALUE) + MIN_ATTACKVALUE;

        this.attackValue = randVal;

    }

    public void setName(String n)
    {
        this.name = n;
    }
    public void setHealthPoints(int h)
    {
        this.healthPoints = h;
    }
    public void setAttackValue(int a)
    {
        this.attackValue = a;
    }

    public String getName()
    {
        return this.name;
    }

    public int getHealthPoints() {
        return this.healthPoints;
    }

    public int getAttackValue() {
        return this.attackValue;
    }
    public String getHeroStats()
    {
        String res = "Name: " + this.name + "\n" + "Health Points: " + this.healthPoints + "\n"+ "Attack Value: " + this.attackValue;
        return res;
    }
    public boolean isInjured()
    {
        if (this.healthPoints <= MIN_HEALTHPOINTS)
        {
            return true;
        }
        else{
            return false;
        }
    }
    public void loseHealthPoints(int n)
    {
        this.healthPoints = this.healthPoints - n;
    }
}



