/* EDIT THIS FILE */

package itp341.javareview.superhero;

public class HeroBattle {

    public String play()
    {
        String res = "";

        Superhero p1 = new Superhero("Wolverine");
        Superhero p2 = new Superhero("Magneto");

        res+=("HEROES\n");
        res+=(p1.getHeroStats()+"\n");
        res+=(p2.getHeroStats()+"\n");
        res += "\n";
        res+=("FIGHT!\n");
        int x = 1;
        while(p1.isInjured() == false && p2.isInjured() == false)
        {
            res+=("===== Round " + x + " =====\n");
            int p1Attack = p1.getAttackValue();
            int p2Attack = p2.getAttackValue();
            p1.loseHealthPoints(p2Attack);
            p2.loseHealthPoints(p1Attack);
            res+=(p1.getHeroStats()+"\n");
            res+=(p2.getHeroStats()+ "\n");
            res+= "\n";

            x++;
        }

        if(p1.isInjured() && p2.isInjured())
        {
            res+=(p1.getName() + " and " + p2.getName() + " have tied!");
        }
        else if (p1.isInjured() && !p2.isInjured())
        {
            res+=(p2.getName() + " won!");
        }
        else{
            res+=(p1.getName() + " won!");
        }


        return res;
    }

}
